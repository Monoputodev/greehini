<!DOCTYPE html>
<html lang="en">


    <head>
        <?php echo $__env->make('web.inc.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>

    <body class="header4">
        <?php echo $__env->make('web.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('main-body'); ?>

        <!-- footer start here -->
        <?php echo $__env->make('web.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- footer end here -->

        <!-- jquery -->
        <?php echo $__env->make('web.inc.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>


</html><?php /**PATH C:\xampp\htdocs\grihini\resources\views/web/app/app.blade.php ENDPATH**/ ?>