<div class="blog">
    <div class="container">
        <div class="commontop text-center">
            <h4>Our Blog</h4>
        </div>
        <div class="row">
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-md-4 col-sm-4 col-lg-4 col-xs-12">
                <div class="box">
                    <a href="<?php echo e(route('blog.details',$blog->id)); ?>">
                        <img class="img-fluid" src="<?php echo e(asset('')); ?>uploads/blogs/<?php echo e($blog->image); ?>" alt="image"
                          title="image">
                    </a>
                    <div class="caption">

                        <h4><?php echo e($blog->title); ?></h4>
                        <p><?php echo e($blog->subtitle); ?></p>
                        <div class="text-right">
                            <a href="<?php echo e(route('blog.details',$blog->id)); ?>">Read More >></a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\grihini\resources\views/web/component/blog.blade.php ENDPATH**/ ?>