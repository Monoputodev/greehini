<?php $__env->startSection('main-body'); ?>
<!-- slider start here -->
<?php echo $__env->make('web.component.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- slider end here -->

<!-- about start here -->
<?php echo $__env->make('web.component.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- about end here -->

<!-- product start here -->
<?php echo $__env->make('web.component.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- product end here -->


<!-- thirdtest start here -->
<?php echo $__env->make('web.component.testimonial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- thirdtest end here -->



<!-- blog start here -->
<?php echo $__env->make('web.component.blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- blog end here -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grihini\resources\views/web/pages/index.blade.php ENDPATH**/ ?>