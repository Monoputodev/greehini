<div class="slide">
    <div class="slideshow1 owl-carousel">
        <?php $__currentLoopData = $heros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="item positon-relative">
            <img src="<?php echo e(asset('')); ?>uploads/heros/<?php echo e($hero->image); ?>" alt="banner" title="banner"
              class="img-fluid sliderchange" />
            <div class="hero-caption d-none d-md-block">
                <h1><?php echo e($hero->title); ?></h1>
                <h5><?php echo e($hero->subtitle); ?></h5>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
</div><?php /**PATH C:\xampp\htdocs\grihini\resources\views/web/component/hero.blade.php ENDPATH**/ ?>