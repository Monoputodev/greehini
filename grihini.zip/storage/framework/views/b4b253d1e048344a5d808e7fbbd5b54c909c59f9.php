<!-- testimonail start here -->
<div class="testimonails">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12 col-xs-12 commontop text-center">
                <h4>Testimonials</h4>
                <div class="img">
                    <img src="<?php echo e(asset('')); ?>assets/web/images/header2/organic-icon.png" alt="icon" title="icon"
                      class="img-fluid" />
                </div>
            </div>
            <div class="col-sm-12 col-xs-12">
                <div class="owl-carousel testimonail1 text-center">
                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <div class="box">
                            <img src="<?php echo e(asset('')); ?>uploads/testimonials/<?php echo e($testimonial->image); ?>" style="height: 50px"
                              class="img-fluid mx-auto" alt="img" title="img" />
                            <p>"<?php echo e($testimonial->description); ?>"</p>
                            <h4>
                                <?php echo e($testimonial->title); ?>

                            </h4>
                            <h6><small class="text-small"><?php echo e($testimonial->subtitle); ?></small>
                            </h6>

                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\agrisunflower\resources\views/web/component/testimonial.blade.php ENDPATH**/ ?>