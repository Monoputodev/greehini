<div class="about">
    <div class="container">
        <div class="commontop text-center">
            <h4>Welcome to <span><?php echo e($content->website_name); ?></span></h4>

        </div>
        <div class="row">
            <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 wid1">
                <div class="bg">
                    <img src="<?php echo e(asset('')); ?>uploads/content/<?php echo e($content->about_image); ?>" alt="img" title="img"
                      class="img-fluid">
                </div>
            </div>
            <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 wid2"><?php echo $content->about_content; ?></p>
                
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\grihini\resources\views/web/component/about.blade.php ENDPATH**/ ?>