<div class="container">
    <div class="row">
        <div class="col-md-12 col-sm-12 col-lg-12 col-xs-12 commontop text-center">
            <h4>Our products</h4>
            <div class="img">
                <img src="<?php echo e(asset('')); ?>assets/web/images/header2/organic-icon.png" alt="icon" title="icon"
                  class="img-fluid" />
            </div>
        </div>
        <div class="col-md-12 col-sm-12 col-lg-12 col-xs-12">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="all-tab" data-bs-toggle="tab" data-bs-target="#all-tab-pane"
                      type="button" role="tab" aria-controls="all-tab-pane" aria-selected="true">All</button>
                </li>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="<?php echo e($category->id); ?>-tab" data-bs-toggle="tab"
                      data-bs-target="#<?php echo e($category->id); ?>-tab-pane" type="button" role="tab"
                      aria-controls="<?php echo e($category->id); ?>-tab-pane" aria-selected="false"><?php echo e($category->title); ?></button>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="all-tab-pane" role="tabpanel" aria-labelledby="all-tab"
                  tabindex="0">
                    <div class="row">
                        <?php $__currentLoopData = $products->take(12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-6">
                            <div class="product-box">
                                <div class="product-thumb">
                                    <div class="image">
                                        <a href="<?php echo e(route('product.details',$product->slug)); ?>">
                                            <img src="<?php echo e(asset('')); ?>uploads/products/<?php echo e($product->image); ?>" alt="image"
                                              title="image" class="img-fluid" />
                                        </a>
                                    </div>
                                    <div class="caption text-center text-dark">

                                        <h5><a
                                              href="<?php echo e(route('product.details',$product->slug)); ?>"><?php echo e($product->title); ?></a>
                                        </h5>


                                    </div>

                                </div>
                            </div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade" id="<?php echo e($category->id); ?>-tab-pane" role="tabpanel"
                  aria-labelledby="<?php echo e($category->id); ?>-tab" tabindex="0">

                    <div class="row">
                        <?php $__currentLoopData = $products->where('product_category',$category->id)->take(12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
                            <div class="product-thumb">
                                <div class="image">
                                    <a href="<?php echo e(route('product.details',$product->slug)); ?>">
                                        <img src="<?php echo e(asset('')); ?>uploads/products/<?php echo e($product->image); ?>" alt="image"
                                          title="image" class="img-fluid" />
                                    </a>
                                </div>
                                <div class="caption">
                                    <div class="float-start">
                                        <h5><a
                                              href="<?php echo e(route('product.details',$product->slug)); ?>"><?php echo e($product->title); ?></a>
                                        </h5>
                                    </div>

                                </div>

                            </div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
</div>
<!-- product end here -->
<?php /**PATH C:\xampp\htdocs\grihini\resources\views/web/component/product.blade.php ENDPATH**/ ?>