<?php $__env->startSection('main-body'); ?>
<!-- Page Title -->
<style>
    img.thumbanail {
        height: 100px;
        width: auto;
        margin: 4px;
    }

    img.preview {
        height: auto;
        width: 100%;
    }

    .swiper-button-next {
        background: #686868;
        padding: 10px;
        opacity: 0.5;
    }

    .swiper-button-prev {
        background: #686868;
        padding: 10px;
        opacity: 0.5;
    }
</style>
<div class="bread-crumb">
    <img src="<?php echo e(asset('')); ?>uploads/category/<?php echo e($product->category->image); ?>" class="img-fluid" alt="banner-top" title="banner-top">
    <div class="container">
        <div class="matter">
            <h2><span><?php echo e($product->title); ?></span> </h2>

        </div>
    </div>
</div>
<!-- End Page Title -->
<div class="shopdetail pb-5">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 col-xs-12">
                <div class="row">
                    <div class="col-sm-4 col-md-4 col-lg-4 col-xs-12">
                        <div style="--swiper-navigation-color: #fff; --swiper-pagination-color: #fff"
                          class="swiper mySwiper2">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <img id="zoom_main" src="<?php echo e(asset('')); ?>uploads/products/<?php echo e($product->image); ?>"
                                      title="img" alt="img" class="preview">
                                    <script>
                                        $("#zoom_main").ezPlus();
                                    </script>
                                </div>
                                <?php if($productPhotos): ?>
                                <?php $__currentLoopData = $productPhotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$thumbnail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide">
                                    <img id="zoom_<?php echo e($k); ?>"
                                      src="<?php echo e(asset('')); ?>uploads/productphoto/<?php echo e($thumbnail->image); ?>"
                                      class="preview" />
                                    <script>
                                        $("#zoom_<?php echo e($k); ?>").ezPlus();
                                    </script>
                                </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                            </div>
                            <div class="swiper-button-next"></div>
                            <div class="swiper-button-prev"></div>
                        </div>

                        <?php if($productPhotos): ?>
                        <div thumbsSlider="" class="swiper mySwiper">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <img src="<?php echo e(asset('')); ?>uploads/products/<?php echo e($product->image); ?>" title="img"
                                      class="thumbanail" alt="img">
                                </div>
                                <?php $__currentLoopData = $productPhotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$thumbnail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide">
                                    <img src="<?php echo e(asset('')); ?>uploads/productphoto/<?php echo e($thumbnail->image); ?>"
                                      class="thumbanail" />
                                </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </div>
                        </div>

                        <?php endif; ?>

                    </div>

                    <!--thumb image code end-->

                    <!--Product detail code start-->
                    <div class="col-sm-8 col-md-8 col-lg-8 col-xs-12">
                        <h5><span><?php echo e($product->title); ?></span></h5>
                        
                        <p class="shortdes">
                            <?php echo $product->description; ?>

                        </p>
                        
                        <hr>

                    </div>
                </div>
            </div>
            <hr>

        </div>

    </div>
</div>

<?php $__env->startPush('script'); ?>

<script>
    $(function () {

        initEZPlus();

        //Triggered when window width is changed.
        $( window ).on( "resize", function() {
            var windowWidth = $( window ).width(), // get window width
                imgWidth = $( "#responsive_img").width(); // get image width
            //Init elevateZoom
            initEZPlus();
            //display status
            $( "#status" ).html("Status: Window resized!.");
            //display image and window width
            $( "#imgWidth" ).html("Image width: " + imgWidth + "px" + "<br />" + "Window width: " + windowWidth + "px");
        });

        function initEZPlus() {
            $("#responsive_img").ezPlus({
                responsive : true,
                scrollZoom : false,
                showLens: true,

                tint: true,
                tintColour: '#0F0',
                tintOpacity: 0.5,
                respond: [
                    {
                        range: '600-799',
                        tintColour: '#F00',
                        zoomWindowHeight: 100,
                        zoomWindowWidth: 100
                    },
                    {
                        range: '800-1199',
                        tintColour: '#00F',
                        zoomWindowHeight: 200,
                        zoomWindowWidth: 200
                    },
                    {
                        range: '100-599',
                        enabled: false,
                        showLens: false
                    }
                ]
            });
        }
    })
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grihini\resources\views/web/pages/product/details.blade.php ENDPATH**/ ?>