<?php $__env->startSection('main-body'); ?>
<div class="bread-crumb">
    <img src="<?php echo e(asset('')); ?>assets/web/images/top-banner.jpg" class="img-fluid" alt="banner-top" title="banner-top">
    <div class="container">
        <div class="matter">
            <h2><span>Products</span> </h2>

        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12 col-sm-12 col-lg-12 col-xs-12 commontop text-center">
            <h4>Our products</h4>
            <div class="img">
                <img src="<?php echo e(asset('')); ?>assets/web/images/header2/organic-icon.png" alt="icon" title="icon"
                  class="img-fluid" />
            </div>
        </div>
        <div class="col-md-12 col-sm-12 col-lg-12 col-xs-12">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="all-tab" data-bs-toggle="tab" data-bs-target="#all-tab-pane"
                      type="button" role="tab" aria-controls="all-tab-pane" aria-selected="true">All</button>
                </li>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="<?php echo e($category->id); ?>-tab" data-bs-toggle="tab"
                      data-bs-target="#<?php echo e($category->id); ?>-tab-pane" type="button" role="tab"
                      aria-controls="<?php echo e($category->id); ?>-tab-pane" aria-selected="false"><?php echo e($category->title); ?></button>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="all-tab-pane" role="tabpanel" aria-labelledby="all-tab"
                  tabindex="0">
                    <div class="row">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
                         <div class="product-box">
                                <div class="product-thumb1 p-2">

                                         <div class="image">
                                                <a href="<?php echo e(route('product.details',$product->slug)); ?>">
                                                    <img src="<?php echo e(asset('')); ?>uploads/products/<?php echo e($product->image); ?>"
                                                      alt="image" title="image" class="img-fluid" />
                                                </a>
                                            </div>

                                            <div class="caption text-dark">

                                                <p><a href="<?php echo e(route('product.details',$product->slug)); ?>"
                                                      class="product-cap"><?php echo e($product->title); ?></a>
                                                </p>
                                                <h6>
                                                    <p  style="font-size: 14px;font-weight: 700;color: #307a3c;"><?php echo e($product->price_range); ?>

                                                    </p>
                                                </h6>
                                                <h6>
                                                    <p class="text-dark"> <?php echo e($product->nature); ?></p>
                                                </h6>
                                                <h6>
                                                    <p class="text-dark"> <?php echo e($product->weight); ?></p>
                                                </h6>

                                                <h6>
                                                    <p class="text-dark"> <?php echo e($product->min_order_qty); ?>  (min. order)
                                                    </p>
                                                </h6>
                                                  <div class="">
                                            <a data-bs-toggle="modal" data-bs-target="#inquiryModal<?php echo e($product->id); ?>" class="btn btn-custom btn-block btn-sm"> Contact supplier</a>
                                            
                                        </div>


                                    </div>



                                </div>
                            </div>
                        </div>
<?php echo $__env->make('web.inc.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade" id="<?php echo e($category->id); ?>-tab-pane" role="tabpanel"
                  aria-labelledby="<?php echo e($category->id); ?>-tab" tabindex="0">

                    <div class="row">
                        <?php $__currentLoopData = $products->where('product_category',$category->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
                            <div class="product-box">
                                   <div class="product-thumb1 p-2">

                                            <div class="image">
                                                   <a href="<?php echo e(route('product.details',$product->slug)); ?>">
                                                       <img src="<?php echo e(asset('')); ?>uploads/products/<?php echo e($product->image); ?>"
                                                         alt="image" title="image" class="img-fluid" />
                                                   </a>
                                               </div>

                                               <div class="caption text-dark">

                                                   <p><a href="<?php echo e(route('product.details',$product->slug)); ?>"
                                                         class="product-cap"><?php echo e($product->title); ?></a>
                                                   </p>
                                                   <h6>
                                                       <p  style="font-size: 14px;font-weight: 700;color: #307a3c;"><?php echo e($product->price_range); ?>

                                                       </p>
                                                   </h6>
                                                   <h6>
                                                       <p class="text-dark"> <?php echo e($product->nature); ?></p>
                                                   </h6>
                                                   <h6>
                                                       <p class="text-dark"> <?php echo e($product->weight); ?></p>
                                                   </h6>

                                                   <h6>
                                                       <p class="text-dark"> <?php echo e($product->min_order_qty); ?>  (min. order)
                                                       </p>
                                                   </h6>
                                                     <div class="">
                                               <a data-bs-toggle="modal" data-bs-target="#inquiryModal<?php echo e($product->id); ?>" class="btn btn-custom btn-block btn-sm"> Contact supplier</a>
                                               
                                           </div>


                                       </div>



                                   </div>
                               </div>
                           </div>
   <?php echo $__env->make('web.inc.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
</div>
<!-- product end here -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\agrisunflower\resources\views/web/pages/product/index.blade.php ENDPATH**/ ?>