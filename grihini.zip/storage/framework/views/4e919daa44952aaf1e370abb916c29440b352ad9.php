<div id="sidebar-menu">
    <!-- Left Menu Start -->
    <ul class="metismenu list-unstyled" id="side-menu">
        <li class="menu-title" key="t-menu">Menu</li>

        <li>
            <a href="<?php echo e(route('contacts.index')); ?>" class="waves-effect">
                <i class="bx bx-home-circle"></i>
                <span key="t-dashboards">Contacts</span>
            </a>

        </li>
        <li>
            <a href="<?php echo e(route('querries.index')); ?>" class="waves-effect">
                <i class="bx bx-home-circle"></i>
                <span key="t-dashboards">Product Querries</span>
            </a>

        </li>
        <li class="menu-title" key="t-menu">Web Contents</li>


        
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="bx bx-home-circle"></i>
                <span key="t-hero">Hero</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(route('heros.index')); ?>" key="t-list">All Hero</a></li>
                <li><a href="<?php echo e(route('heros.create')); ?>" key="t-create">Create Hero</a></li>

            </ul>
        </li>
        

        
        
    

    
    
    

    
    <li>
        <a href="javascript: void(0);" class="has-arrow waves-effect">
            <i class="bx bx-home-circle"></i>
            <span key="t-testimonial">Testimonial</span>
        </a>
        <ul class="sub-menu" aria-expanded="false">
            <li><a href="<?php echo e(route('testimonials.index')); ?>" key="t-list">All Testimonial</a></li>
            <li><a href="<?php echo e(route('testimonials.create')); ?>" key="t-create">Create Testimonial</a></li>

        </ul>
    </li>
    

    
    
    


    
    <li>
        <a href="javascript: void(0);" class="has-arrow waves-effect">
            <i class="bx bx-home-circle"></i>
            <span key="t-category">Category</span>
        </a>
        <ul class="sub-menu" aria-expanded="false">
            <li><a href="<?php echo e(route('categories.index')); ?>" key="t-list">All Category</a></li>
            <li><a href="<?php echo e(route('categories.create')); ?>" key="t-create">Create Category</a></li>

        </ul>
    </li>
    

    
    <li>
        <a href="javascript: void(0);" class="has-arrow waves-effect">
            <i class="bx bx-home-circle"></i>
            <span key="t-product">product</span>
        </a>
        <ul class="sub-menu" aria-expanded="false">
            <li><a href="<?php echo e(route('products.index')); ?>" key="t-list">All product</a></li>
            <li><a href="<?php echo e(route('products.create')); ?>" key="t-create">Create product</a></li>

        </ul>
    </li>
    



    
    <!--<li>-->
    <!--    <a href="javascript: void(0);" class="has-arrow waves-effect">-->
    <!--        <i class="bx bx-home-circle"></i>-->
    <!--        <span key="t-blog">Blog</span>-->
    <!--    </a>-->
    <!--    <ul class="sub-menu" aria-expanded="false">-->
    <!--        <li><a href="<?php echo e(route('blogs.index')); ?>" key="t-list">All Blog</a></li>-->
    <!--        <li><a href="<?php echo e(route('blogs.create')); ?>" key="t-create">Create Blog</a></li>-->

    <!--    </ul>-->
    <!--</li>-->
    

    <li>
        <a href="javascript: void(0);" class="has-arrow waves-effect">
            <i class="bx bx-home-circle"></i>
            <span key="t-hero">Website Content</span>
        </a>
        <ul class="sub-menu" aria-expanded="false">
            <li><a href="<?php echo e(route('about.edit', 1)); ?>" key="t-list">About Us</a></li>
            <li><a href="<?php echo e(route('contact.edit', 1)); ?>" key="t-list">Contact Info</a></li>
            <li><a href="<?php echo e(route('general.edit', 1)); ?>" key="t-list">General Setting</a></li>

        </ul>

    </li>
    
    </ul>
</div>
<?php /**PATH C:\xampp\htdocs\agrisunflower\resources\views/admin/inc/sidebar.blade.php ENDPATH**/ ?>