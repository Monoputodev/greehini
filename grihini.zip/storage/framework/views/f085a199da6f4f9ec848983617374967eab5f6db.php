<header class="">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-4 col-lg-4 col-xs-12 top order-md-1 order-2">
                <ul class="list-inline float-start icon">
                    <li class="list-inline-item">
                        <a href="contactus.html">
                            <img width="30" height="30" src="<?php echo e(asset('')); ?>assets/web/images/phone.png" alt="ringing-phone"/>  <span><?php echo e($content->website_phone); ?></span>
                        </a>
                    </li>

                </ul>
            </div>
            <div class="col-md-4 col-sm-4 col-lg-4 col-xs-12 order-md-2 order-1">
                <div id="logo">
                    <a href="<?php echo e(route('index')); ?>">
                        <img class="img-fluid logochange"
                          src="<?php echo e(asset('')); ?>uploads/content/<?php echo e($content->website_logo); ?>" alt="logo" title="logo">
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-4 col-lg-4 col-xs-12 top order-md-3 order-3">
                <ul class="list-inline float-end  icons">
                    <li class="list-inline-item">
                        <ul class="list-inline social">
                            <li class="list-inline-item">
                                <a href="<?php echo e($content->facebook); ?>" target="_blank">
                                    <i class="social_facebook"></i>
                                </a>
                            </li>
                            <li class="list-inline-item">
                                <a href="<?php echo e($content->whatsapp); ?>" target="_blank">
                                    <i class="fa-brands fa-whatsapp"></i>
                                </a>
                            </li>
                            <li class="list-inline-item">
                                <a href="<?php echo e($content->youtube); ?>" target="_blank">
                                    <i class="social_youtube"></i>
                                </a>
                            </li>
                            <li class="list-inline-item">
                                <a href="<?php echo e($content->linkdin); ?>" target="_blank">
                                    <i class="social_linkedin"></i>
                                </a>
                            </li>
                               <li class="list-inline-item">
                                <a href="<?php echo e($content->skype); ?>" target="_blank">
                                    <i class="fa-brands fa-skype"></i>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</header>


<div class="menu1">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12 col-xs-12">
                <!-- menu start here -->
                <div id="menu">
                    <nav class="navbar navbar-expand-lg">
                        <span class="menutext visible-xs">Menu</span>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                          data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                          aria-expanded="false" aria-label="Toggle navigation"><span
                              class="navbar-toggler-icon"></span></button>
                        <div class="collapse navbar-collapse padd0" id="navbarSupportedContent">
                            <ul class="nav navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('index')); ?>">Home</a>
                                </li>
                                <li class="dropdown topheading">
                                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                      aria-expanded="false">Category</a>
                                    <div class="dropdown-menu">
                                        <div class="dropdown-inner">
                                            <ul class="list-unstyled">

                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a
                                                      href="<?php echo e(route('service.details',$category->id)); ?>"><?php echo e($category->title); ?></a>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                            </ul>
                                        </div>
                                    </div>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('product.index')); ?>">Products</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('about')); ?>">About us</a>
                                </li>

                                <li>
                                    <a class="nav-link" href="<?php echo e(route('contact')); ?>">Contact us</a>
                                </li>
                                <!--<li class="nav-item">-->
                                <!--    <a class="nav-link" href="<?php echo e(route('blogs.all')); ?>">Blogs</a>-->
                                <!--</li>-->
                            </ul>
                        </div>
                    </nav>
                </div>
                <!-- menu end here -->
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\agrisunflower\resources\views/web/inc/header.blade.php ENDPATH**/ ?>