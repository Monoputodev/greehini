<style>
    /* Custom CSS for Alibaba-style inquiry modal */
  /* Custom CSS for the stylish inquiry modal */
  .inquiry-modal {
      background-color: rgba(0, 0, 0, 0.7);
    }

    .inquiry-modal-dialog {
      max-width: 600px;
      border-radius: 10px;
    }

    .inquiry-modal-content {
      border: none;
      border-radius: 10px;
      box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
    }

    .inquiry-modal-header {
      background-color: #f5f5f5;
      padding: 20px;
      border-radius: 10px 10px 0 0;
      display: flex;
      align-items: center;
    }

    .inquiry-modal-title {
      font-size: 14px!important;
      margin: 0;
      flex-grow: 1;
    }

    .inquiry-modal-image {
      max-width: 100px;
      max-height: 100px;
      margin-right: 20px;
    }

    .inquiry-modal-body {
      padding: 20px;
    }

    .inquiry-form-label {
      font-weight: bold;
    }

    .inquiry-modal-footer {
      background-color: #f5f5f5;
      padding: 20px;
      border-radius: 0 0 10px 10px;
    }
  </style>



<div class="modal fade" id="inquiryModal<?php echo e($product->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog inquiry-modal-dialog">
      <div class="modal-content inquiry-modal-content">
        <div class="modal-header inquiry-modal-header">
          <img src="<?php echo e(asset('')); ?>uploads/products/<?php echo e($product->image); ?>" alt="Product Image" style="height: 45px" class="inquiry-modal-image">
          <p class="modal-title inquiry-modal-title" id="exampleModalLabel"><?php echo e($product->title); ?></p>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body inquiry-modal-body">
          <!-- Inquiry form -->
          <form action="<?php echo e(route('querry.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
            <div class="mb-3">
              <label for="name" class="form-label inquiry-form-label">Your Name</label>
              <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="mb-3">
              <label for="email" class="form-label inquiry-form-label">Your Email</label>
              <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="mb-3">
                <label for="phone" class="form-label inquiry-form-label">Your Phone</label>
                <input type="phone" class="form-control" id="phone" name="phone" required>
              </div>
            <div class="mb-3">
              <label for="message" class="form-label inquiry-form-label">Message</label>
              <textarea class="form-control" id="message" name="comment" rows="4"></textarea>
            </div>
            <div class="mb-3">
              <label for="quantity" class="form-label inquiry-form-label">Quantity</label>
              <input type="number" class="form-control" name="quantity" id="quantity">
            </div>
            <div class="mb-3">
              <label for="file" class="form-label inquiry-form-label">Attachment </label>
              <input type="file" name="file" class="form-control-file dropify" id="file">
            </div>
            <button type="submit" class="btn btn-primary">Send Inquiry</button>
          </form>
        </div>
        <div class="modal-footer inquiry-modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

        </div>
      </div>
    </div>
  </div>
<?php /**PATH C:\xampp\htdocs\agrisunflower\resources\views/web/inc/modal.blade.php ENDPATH**/ ?>