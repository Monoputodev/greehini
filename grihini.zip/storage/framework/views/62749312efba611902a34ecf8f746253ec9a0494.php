<title><?php echo e($content->website_name); ?></title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- Bootstrap stylesheet -->
<link href="<?php echo e(asset('')); ?>assets/web/js/bootstrap5.3/css/bootstrap.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/css/dropify.css" integrity="sha512-In/+MILhf6UMDJU4ZhDL0R0fEpsp4D3Le23m6+ujDWXwl3whwpucJG1PEmI3B07nyJx+875ccs+yX2CqQJUxUw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<!-- crousel css -->
<link href="<?php echo e(asset('')); ?>assets/web/css/owl.carousel.css" rel="stylesheet" type="text/css" />
<!--bootstrap select-->
<link href="js/dist/css/bootstrap-select.css" rel="stylesheet" type="text/css" />
<!-- font -->
<link href="https://fonts.googleapis.com/css?family=Fira+Sans:300,400,500,600,700,800,900%7CPT+Serif:400,700"
  rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
<!-- font-awesome -->
<link rel="stylesheet" href="<?php echo e(asset('')); ?>assets/web/assets/fonts/fontawesome/css/all.min.css">
<link href="<?php echo e(asset('')); ?>assets/web/css/ele-style.css" rel="stylesheet" type="text/css" />
<!-- stylesheet -->
<link href="<?php echo e(asset('')); ?>assets/web/css/style.css" rel="stylesheet" type="text/css" />
<?php /**PATH C:\xampp\htdocs\agrisunflower\resources\views/web/inc/head.blade.php ENDPATH**/ ?>