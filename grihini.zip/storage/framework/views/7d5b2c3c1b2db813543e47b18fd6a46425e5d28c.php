<?php $__env->startSection('main-body'); ?>
<div class="bread-crumb">
    <img src="<?php echo e(asset('')); ?>assets/web/images/top-banner.jpg" class="img-fluid" alt="banner-top" title="banner-top">
    <div class="container">
        <div class="matter">
            <h2><span>Products</span> </h2>

        </div>
    </div>
</div>
<?php echo $__env->make('web.component.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grihini\resources\views/web/pages/product/index.blade.php ENDPATH**/ ?>