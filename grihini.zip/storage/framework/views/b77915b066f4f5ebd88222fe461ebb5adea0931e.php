<?php $__env->startSection('main-body'); ?>
<div class="bread-crumb">
    <img src="<?php echo e(asset('')); ?>uploads/category/<?php echo e($category->image); ?>" class="img-fluid" alt="banner-top" title="banner-top">
    <div class="container">
        <div class="matter">
            <h2><span><?php echo e($category->title); ?></span> </h2>

        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12 col-sm-12 col-lg-12 col-xs-12 commontop text-center">
            <h4><?php echo e($category->title); ?></h4>
            <div class="img">
                <img src="<?php echo e(asset('')); ?>assets/web/images/header2/organic-icon.png" alt="icon" title="icon"
                  class="img-fluid" />
            </div>
        </div>
        <div class="col-md-12 col-sm-12 col-lg-12 col-xs-12">
            <div class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 col-lg-3 col-sm-4 col-xs-6">
                    <div class="product-box">
                        <div class="product-thumb">
                            <div class="image">
                                <a href="<?php echo e(route('product.details',$product->slug)); ?>">
                                    <img src="<?php echo e(asset('')); ?>uploads/products/<?php echo e($product->image); ?>" alt="image"
                                      title="image" class="img-fluid" />
                                </a>
                            </div>
                            <div class="caption text-center text-dark">

                                <h5><a href="<?php echo e(route('product.details',$product->slug)); ?>"><?php echo e($product->title); ?></a>
                                </h5>


                            </div>

                        </div>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
</div>
<!-- product end here -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grihini\resources\views/web/pages/category/details.blade.php ENDPATH**/ ?>