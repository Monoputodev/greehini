<meta charset="utf-8" />
<title>{{ $content->website_name }}- Dashoard</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" type="image/x-icon" href="{{ asset('') }}assets/web/images/favicon.ico">
<!-- App favicon -->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/css/dropify.css" integrity="sha512-In/+MILhf6UMDJU4ZhDL0R0fEpsp4D3Le23m6+ujDWXwl3whwpucJG1PEmI3B07nyJx+875ccs+yX2CqQJUxUw==" crossorigin="anonymous" referrerpolicy="no-referrer" />


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.7.1/css/lightgallery-bundle.css" integrity="sha512-99QS7EyPaI2GCrlnsXgQIyeqiblx5KxSXitcae8/6dW3pEoLYyIMehBL7kTANqFCLPPk/jadeTrdeb6yM+LDJA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <!-- Sweet Alert-->
        <link href="{{ asset('/assets') }}/admin/libs/sweetalert2/sweetalert2.min.css" rel="stylesheet" type="text/css" />

        <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet">
<!-- Bootstrap Css -->
<link href="{{ asset('/assets') }}/admin/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
<!-- Icons Css -->
<link href="{{ asset('/assets') }}/admin/css/icons.min.css" rel="stylesheet" type="text/css" />
<!-- App Css-->
<link href="{{ asset('/assets') }}/admin/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />


