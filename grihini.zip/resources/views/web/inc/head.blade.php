<title>{{ $content->website_name }}</title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- Bootstrap stylesheet -->
<link href="{{asset('')}}assets/web/js/bootstrap5.3/css/bootstrap.min.css" rel="stylesheet" />
<!-- crousel css -->
<link href="{{asset('')}}assets/web/css/owl.carousel.css" rel="stylesheet" type="text/css" />
<!--bootstrap select-->
<link href="js/dist/css/bootstrap-select.css" rel="stylesheet" type="text/css" />
<!-- font -->
<link href="https://fonts.googleapis.com/css?family=Fira+Sans:300,400,500,600,700,800,900%7CPT+Serif:400,700"
  rel="stylesheet">
<!-- font-awesome -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
<link rel="stylesheet" href="{{asset('')}}assets/web/assets/fonts/fontawesome/css/all.min.css">
<link href="{{asset('')}}assets/web/css/ele-style.css" rel="stylesheet" type="text/css" />
<!-- stylesheet -->
<link href="{{asset('')}}assets/web/css/style.css" rel="stylesheet" type="text/css" />
