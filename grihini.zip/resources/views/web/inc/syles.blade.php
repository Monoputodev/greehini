


<!-- Bootstrap  v5.1.3 css -->
<link rel="stylesheet" href="{{ asset('') }}assets/web//css/bootstrap.min.css" />
<!-- Sall css -->
<link rel="stylesheet" type="text/css" href="{{ asset('') }}assets/web//css/sal.css" />
<!-- magnific css -->
<link rel="stylesheet" type="text/css" href="{{ asset('') }}assets/web//css/magnific-popup.css" />
<!-- Swiper Slider css -->
<link rel="stylesheet" type="text/css" href="{{ asset('') }}assets/web//css/swiper.min.css" />
<!-- Remixicon Fonts css -->
<link rel="stylesheet" type="text/css" href="{{ asset('') }}assets/web//css/ico-fonts.css" />
<!-- Remixicon Fonts css -->
<link rel="stylesheet" type="text/css" href="{{ asset('') }}assets/web//css/odometer.min.css" />
<!-- style css -->
<link rel="stylesheet" type="text/css" href="{{ asset('') }}assets/web//css/style.css" />

